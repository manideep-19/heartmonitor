package com.example.health;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.hardware.Camera;
import android.os.Bundle;
import android.os.Handler;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.widget.TextView;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.util.ArrayList;
import java.util.List;

public class HealthMonitorActivity extends Activity {

    private static final String TAG = "HealthMonitorActivity";

    private SurfaceView surfaceView;
    private TextView heartRateText;
    private Camera camera;
    private SurfaceHolder surfaceHolder;
    private Handler handler = new Handler();

    private List<Integer> greenIntensities = new ArrayList<>();
    private long lastTime = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_health_monitor);

        surfaceView = findViewById(R.id.surfaceView);
        heartRateText = findViewById(R.id.heartRateText);

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CAMERA}, 200);
        }

        surfaceHolder = surfaceView.getHolder();
        surfaceHolder.addCallback(surfaceCallback);
    }

    private SurfaceHolder.Callback surfaceCallback = new SurfaceHolder.Callback() {
        @Override
        public void surfaceCreated(SurfaceHolder holder) {
            try {
                camera = Camera.open();  // Using the deprecated Camera API
                camera.setPreviewDisplay(holder);
                camera.setPreviewCallback(previewCallback);
                camera.startPreview();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        @Override
        public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {}

        @Override
        public void surfaceDestroyed(SurfaceHolder holder) {
            if (camera != null) {
                camera.stopPreview();
                camera.release();
                camera = null;
            }
        }
    };

    private Camera.PreviewCallback previewCallback = new Camera.PreviewCallback() {
        @Override
        public void onPreviewFrame(byte[] data, Camera camera) {
            Camera.Parameters parameters = camera.getParameters();
            int width = parameters.getPreviewSize().width;
            int height = parameters.getPreviewSize().height;

            int[] pixels = new int[width * height];
            decodeYUV420SP(pixels, data, width, height);

            int greenIntensity = 0;
            for (int i = 0; i < pixels.length; i++) {
                int pixel = pixels[i];
                int green = (pixel >> 8) & 0xff;  // Extract green channel
                greenIntensity += green;
            }
            greenIntensity /= pixels.length;

            greenIntensities.add(greenIntensity);

            long currentTime = System.currentTimeMillis();
            if (currentTime - lastTime >= 1000) {
                estimateHeartRate();
                greenIntensities.clear();
                lastTime = currentTime;
            }
        }
    };

    private void decodeYUV420SP(int[] output, byte[] input, int width, int height) {
        final int frameSize = width * height;
        int uvIndex = frameSize;
        int u = 0, v = 0;
        int y, y1192;
        int r, g, b;

        for (int j = 0, yp = 0; j < height; j++) {
            for (int i = 0; i < width; i++, yp++) {
                y = (0xff & ((int) input[yp])) - 16;
                if (y < 0) y = 0;
                if ((i & 1) == 0 && (j & 1) == 0) {
                    v = (0xff & ((int) input[uvIndex++])) - 128;
                    u = (0xff & ((int) input[uvIndex++])) - 128;
                }
                y1192 = 1192 * y;
                r = (y1192 + 1634 * v);
                g = (y1192 - 833 * v - 400 * u);
                b = (y1192 + 2066 * u);
                if (r < 0) r = 0;
                else if (r > 255) r = 255;
                if (g < 0) g = 0;
                else if (g > 255) g = 255;
                if (b < 0) b = 0;
                else if (b > 255) b = 255;
                output[yp] = 0xff000000 | (r << 16) | (g << 8) | b;
            }
        }
    }

    private void estimateHeartRate() {
        if (greenIntensities.size() < 2) return;

        double average = 0;
        for (int intensity : greenIntensities) {
            average += intensity;
        }
        average /= greenIntensities.size();

        int peaks = 0;
        for (int i = 1; i < greenIntensities.size() - 1; i++) {
            if (greenIntensities.get(i) > average && greenIntensities.get(i - 1) < average && greenIntensities.get(i + 1) < average) {
                peaks++;
            }
        }

        double heartRate = peaks * 60.0;
        heartRateText.setText(String.format("Heart Rate: %.2f BPM", heartRate));
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 200) {
            if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                camera = Camera.open();
            } else {
                heartRateText.setText("Permission denied");
            }
        }
    }
}
