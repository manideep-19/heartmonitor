package com.example.health;


import android.Manifest;
import android.content.ContentResolver;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

public class EmergencyActivity extends AppCompatActivity {

    private static final int REQUEST_CALL_PERMISSION = 1;
    private static final int REQUEST_CONTACT_PERMISSION = 2;
    private static final int PICK_CONTACT = 3;
    private String emergencyContactNumber;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_emergency);

        Button selectContactButton = findViewById(R.id.btn_select_contact);
        Button emergencyCallButton = findViewById(R.id.btn_call_emergency);

        // Allow the user to select a contact
        selectContactButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Check for contacts permission
                if (ActivityCompat.checkSelfPermission(EmergencyActivity.this, Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(EmergencyActivity.this, new String[]{Manifest.permission.READ_CONTACTS}, REQUEST_CONTACT_PERMISSION);
                } else {
                    pickContact();
                }
            }
        });

        // Call the emergency contact
        emergencyCallButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (emergencyContactNumber != null) {
                    // Request permission for calling if needed
                    if (ActivityCompat.checkSelfPermission(EmergencyActivity.this, Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
                        ActivityCompat.requestPermissions(EmergencyActivity.this, new String[]{Manifest.permission.CALL_PHONE}, REQUEST_CALL_PERMISSION);
                    } else {
                        makeEmergencyCall();
                    }
                } else {
                    Toast.makeText(EmergencyActivity.this, "No emergency contact selected.", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    // Handle the result of the contact picking
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == REQUEST_CONTACT_PERMISSION) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                pickContact();
            } else {
                Toast.makeText(this, "Permission to access contacts denied", Toast.LENGTH_SHORT).show();
            }
        } else if (requestCode == REQUEST_CALL_PERMISSION) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                makeEmergencyCall();
            } else {
                Toast.makeText(this, "Permission to make calls denied", Toast.LENGTH_SHORT).show();
            }
        }
    }

    // Launch the contacts picker
    private void pickContact() {
        Intent pickContactIntent = new Intent(Intent.ACTION_PICK, ContactsContract.CommonDataKinds.Phone.CONTENT_URI);
        startActivityForResult(pickContactIntent, PICK_CONTACT);
    }

    // Handle the result of contact selection
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == PICK_CONTACT && resultCode == RESULT_OK) {
            Uri contactUri = data.getData();
            Cursor cursor = getContentResolver().query(contactUri, null, null, null, null);
            if (cursor != null && cursor.moveToFirst()) {
                int columnIndex = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER);
                emergencyContactNumber = cursor.getString(columnIndex);
                cursor.close();
                Toast.makeText(this, "Emergency contact selected: " + emergencyContactNumber, Toast.LENGTH_SHORT).show();
            }
        }
    }

    // Make the emergency call to the selected contact
    private void makeEmergencyCall() {
        if (emergencyContactNumber != null) {
            Intent callIntent = new Intent(Intent.ACTION_CALL, Uri.parse("tel:" + emergencyContactNumber));
            startActivity(callIntent);
        }
    }
}
