package com.example.health;


import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Emergency button
        Button emergencyButton = findViewById(R.id.btn_emergency);
        emergencyButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navigate to the emergency screen
                Intent intent = new Intent(MainActivity.this, EmergencyActivity.class);
                startActivity(intent);
            }
        });

        // Health monitor button
        Button healthMonitorButton = findViewById(R.id.btn_health_monitor);
        healthMonitorButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navigate to health monitoring screen
                Intent intent = new Intent(MainActivity.this, HealthMonitorActivity.class);
                startActivity(intent);
            }
        });
    }
}
